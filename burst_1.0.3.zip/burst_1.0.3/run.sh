java -cp burst.jar:lib/*:conf nxt.Nxt
