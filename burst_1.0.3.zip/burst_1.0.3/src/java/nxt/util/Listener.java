package nxt.util;

public interface Listener<T> {

    public void notify(T t);

}